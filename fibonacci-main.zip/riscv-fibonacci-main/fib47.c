#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>


static uint64_t fib(uint64_t n) {
  if (n <= 1) return n;
  return fib(n - 1) + fib(n - 2);
}

int main(void) {
  struct timeval start, end;
  gettimeofday(&start, NULL);
  printf("%lu \n", fib(47));
  gettimeofday(&end, NULL); 	
  long elapsed = (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000;
  printf("%ld\n", elapsed);
  return 0;
}
